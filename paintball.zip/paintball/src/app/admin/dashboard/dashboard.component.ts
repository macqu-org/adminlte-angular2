import { Component, OnInit } from '@angular/core';

import { DashboardService} from './../../jogos/jogo.service';
import { DialogService} from './../../dialog.service';
import { Jogo } from './../jogo.service';


@Component({
  selector: 'admin-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  jogos: Jogo[] = [];
  mensagem: {};
  classesCss: {};
  private currentTimeout: any;
  
  constructor(
        private DashboardService: DashboardService,
        private dialogService: DialogService
    ) {}

    ngOnInit(): void {
        this.jogoService.findAll()
        .then((contatos: Contato[]) => {
            this.contatos = contatos;            
        })
        .catch(err => {
            this.mostrarMensagem({
                tipo: 'danger',
                texto: 'Ocorreu um erro ao buscar a lista de contatos!'
            });
        });
    }

    onDelete(contato: Jogo): void {
        this.dialogService.confirm('Deseja deletar o contato ' + contato.nome + '?')
            .then((canDelete: boolean) => {

                if(canDelete) {
                    this.contatoService
                        .delete(contato)
                        .then(() => {

                            this.contatos = this.contatos.filter((c: Contato) => c.id != contato.id);

                            this.mostrarMensagem({
                                tipo: 'success',
                                texto: 'Contato deletado!'
                            });

                        }).catch(err => {
                            this.mostrarMensagem({
                                tipo: 'danger',
                                texto: 'Ocorreu um erro ao deletar o contato!'
                            });
                        })
                }
            });
    }

    private mostrarMensagem(mensagem : {tipo: string, texto: string}): void {
        this.mensagem = mensagem;
        this.montarClasses(mensagem.tipo);
        if(mensagem.tipo != 'danger'){

            if(this.currentTimeout) {
                clearTimeout(this.currentTimeout);
            }
            
            this.currentTimeout = setTimeout(() => {
                this.mensagem = undefined;
            }, 3000);
        }        
    }

    private montarClasses(tipo: string): void {
        this.classesCss = {
            'alert': true
        };
        this.classesCss['alert-' + tipo] = true; // alert-tipo (tipo = danger, warning, success)       
    }
}