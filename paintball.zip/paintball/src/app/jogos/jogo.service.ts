import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';

import { Observable } from 'rxjs';
import 'rxjs/add/operator/toPromise';

//import { Contato } from './contato.model';
//import { CONTATOS } from './contatos-mock';
import { ServiceInterface } from './../../interfaces/service.interface';

@Injectable()

export class DashboardService implements ServiceInterface<Jogo> {

    private dashboardUrl: string = 'app/admin';
    private headers: Headers = new Headers({'Content-Type': 'application/json'});

    constructor(
        private http: Http
    ){}

    findAll(): Promise<Jogo[]> {
        return this.http.get(this.dashboardUrl)
            .toPromise()
            .then(response => response.json().data as Jogo[])
            .catch(this.handleError);
    }

    find(id: number): Promise<Jogo> {
        return this.findAll()
        .then((jogos: Jogo[]) => jogos.find(jogo => jogo.id === id));
    }

    create(contato: Jogo): Promise<Jogo> {
        return this.http
            .post(this.dashboardUrl, JSON.stringify(jogo), {headers: this.headers})
            .toPromise()
            .then((response: Response) => response.json().data as Jogo)
            .catch(this.handleError);
    }

    update(contato: Jogo): Promise<Jogo> {
        
        const url = `${this.dashboardUrl}/${jogo.id}`; // app/admin/:id
        
        return this.http
            .put(url, JSON.stringify(jogo), {headers: this.headers})
            .toPromise()
            .then(() => contato as Jogo)
            .catch(this.handleError);
    }

    delete(contato: Jogo): Promise<Jogo> {
        
        const url = `${this.dashboardUrl}/${jogo.id}`; // app/admin/:id
        
        return this.http
            .delete(url, {headers: this.headers})
            .toPromise()
            .then(() => contato as Jogo)
            .catch(this.handleError);
    }    

    private handleError(err: any): Promise<any> {
        return Promise.reject(err.message || err);
    }

    getContatosSlowly(): Promise<Jogo[]> {
        return new Promise((resolve, reject) => {
            setTimeout(resolve, 2000);
        })
        .then(()=> {
            console.log('primeiro then');
            return 'Curso Angular 2 Fábio Alves';
        })
        .then((param: string)=> {
            console.log('segundo then');
            console.log(param);

            return new Promise((resolve2, reject2) => {
                setTimeout(() => {
                    console.log('continuando depois de 4 segundos...');
                    resolve2();
                }, 4000);
            });
        })
        .then(() => {
            console.log('terceiro then');
            return this.findAll();
        });
    }

    search(term: string): Observable<Jogo[]>{
        return this.http
        .get(`${this.dashboardUrl}/?nome=${term}`)
        .map((res: Response) => res.json().data as Jogo[]);
    }
}