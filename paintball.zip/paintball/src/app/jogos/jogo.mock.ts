import { Jogo } from './jogo.model';

export const CONTATOS: Jogo[] = [
    {id: 1, status: 'Em jogo', horario: '8:00 às 9:00', evento: 'PaintBall dia de semana'},
    {id: 1, status: 'Em jogo', horario: '8:00 às 9:00', evento: 'PaintBall dia de semana'},
    {id: 1, status: 'Em jogo', horario: '8:00 às 9:00', evento: 'PaintBall dia de semana'},
    {id: 1, status: 'Em jogo', horario: '8:00 às 9:00', evento: 'PaintBall dia de semana'},
    {id: 1, status: 'Em jogo', horario: '8:00 às 9:00', evento: 'PaintBall dia de semana'},    
]