export class Jogo {

    constructor(
        public id: number,
        public status: string,
        public horario: string,
        public evento: string
    ){}
}