import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-main-side',
  templateUrl: './main-side.component.html',
  styleUrls: ['./main-side.component.css']
})
export class MainSideComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
