import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'admin-control-sidebar',
  templateUrl: './control-sidebar.component.html',
  styleUrls: ['./control-sidebar.component.css']
})
export class ControlSidebarComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
